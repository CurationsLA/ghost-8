/**
 * legacy.js
 * Placeholder for any deprecated or soon-to-be-removed logic.
 * Keep this file empty or use it to polyfill older browsers if needed.
 *
 * Example (uncomment if you need smooth scroll polyfill):
 *
 * if (!('scrollBehavior' in document.documentElement.style)) {
 *   // Load a polyfill dynamically
 *   import('https://cdn.jsdelivr.net/npm/seamless-scroll-polyfill@latest/lib/bundle.min.js')
 *     .then(mod => mod.default && mod.default());
 * }
 */